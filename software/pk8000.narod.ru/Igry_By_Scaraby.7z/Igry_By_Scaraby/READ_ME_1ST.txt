========================================================================
Dopolnitelnye programy i igry dlia Xobbi PK8000 from SCARABY Collection
------------------------------------------------------------------------
Zapuskat v emuliatore s saita http://bashkiria-2m.narod.ru/:

1. Programmy s kataloga BAS zagruzhat tak:
esli naprimer fail "arkan.cas"
v emuliatore pishem:
CLOAD"ARKAN",R
(esli automaticeski ne zapustilas' programma, to zhmem F5, ili pishem RUN)

2. Programmy s kataloga HEX zagruzhat tak:
esli naprimer fail "alibab.cas"
v emuliatore pishem:
BLOAD"ALIBAB",R

2.1. V kataloge HEX\TEXT_HLP naxoditsia fail "instr.cas"
on zagruzhaetsia v tekstovom redkatore "text.cas"
eto instrukcija polzovatelia

------------------------------------------------------------------------
Bolshe informacii: http://pk8000.narod.ru
------------------------------------------------------------------------
Derevo vsex program i igr
+---BAS
|       arkan.cas
|       ball.cas
|       balls.cas
|       banker.cas
|       biorit.cas
|       castle.cas
|       elita.cas
|       fisher.cas
|       fruit.cas
|       garden.cas
|       gate.cas
|       gonki.cas
|       kod.cas
|       muzred.cas
|       otello.cas
|       presid.cas
|       races.cas
|       rally.cas
|       revers.cas
|       skippy.cas
|       snake.cas
|       soko.cas
|       speed.cas
|       test.cas
|       wampir.cas
|       
\---HEX
    |   alibab.cas
    |   assm.cas
    |   ball3.cas
    |   check.cas
    |   copy09.cas
    |   digger.cas
    |   flyer.cas
    |   galaxy.cas
    |   ice.cas
    |   key.cas
    |   lifter.cas
    |   mars.cas
    |   pacman.cas
    |   pilot.cas
    |   push.cas
    |   putup.cas
    |   pyram.cas
    |   ren2.cas
    |   rk86.cas
    |   soccer.cas
    |   space.cas
    |   squash.cas
    |   stalk.cas
    |   sucobr.cas
    |   text.cas
    |   utilit.cas
    |   
    \---TEXT_HLP
            instr.cas
========================================================================

