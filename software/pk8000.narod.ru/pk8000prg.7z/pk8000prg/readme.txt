=============================================================
NR00_CAS - Basic programs pack from Xobbi PK8000
-------------------------------------------------------------
Listing:
CHISLO, KLAD, MINER, MORBOJ, SURA, TANEC, TEST, AVTO, PITON, TAPLAP

=============================================================
NR01-09_12-14_CAS - Additional programs pack for PK8000
-------------------------------------------------------------
Listing:
SLALOM, SNIPER, CHESS, FIRE, TENNIS, TENNIS, VISNIA, COLOR, MUM, BIRZHA,
TAWER, UDAVIK, WARP, PATNAS, POLET, GAME, BIO, KALEND, SUDBA, TEMPER, 
GG, GRED, PENCIL, ASSM, DESA, EDIT, PLAY, REN, ABVGD, UROK1, UROK2, UROK3,
KAZINO, SCB, BALL, BANKIR, KLAD2, RALLY, FIELD, SPACE, BALL2, KILL1, TETRUB, 
FLYBAL, BOMBER, POKER, TESTZH, CRUX, LAB.

Added at 2008 Sept 12: PREZID and LAMBA(for "PK8000 Xobbi" only)


=============================================================
More information: http://pk8000.narod.ru
=============================================================